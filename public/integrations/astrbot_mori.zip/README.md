# AstrBot × Mori

可直接安装的 AstrBot 命令插件，通过 Mori 的 HMAC 桥接收发 QQ、微信、飞书消息。只处理 `/mori` 命令，不接管普通聊天，不调用 AstrBot 模型，不读取模型密钥。Python 3.9+，仅使用标准库及宿主提供的 AstrBot API。

## 安装与配置

1. 将本目录内 `main.py`、`metadata.yaml`、`_conf_schema.json`、`README.md` 放在 ZIP 根目录，通过 AstrBot 插件管理的本地插件上传入口安装；也可把目录复制为 AstrBot `data/plugins/astrbot_plugin_mori` 并重启。无需安装额外 Python 包。
2. 先在 AstrBot 配置好对应平台 Bot。此插件负责 Mori 转发，不代替平台账号、Bot 审核或适配器登录。
3. Mori 设置中启用渠道桥接，填写随机签名密钥。AstrBot 插件配置填写相同 `bridge_secret` 与可访问的 `mori_url`。容器里的 `127.0.0.1` 指容器自身，应按部署网络填写服务地址。
4. 同时填写用户与会话白名单。用户为 `qq:用户ID`、`wechat:用户ID` 或 `feishu:用户ID`；会话填写 AstrBot `/sid` 得到的完整 UMO。两项都必须匹配，任一空列表默认拒绝，不会向未授权用户回消息。管理员需从平台管理界面确认发送者用户 ID。
5. 自动映射 `aiocqhttp`、`qq_official`、`qq_official_webhook` 至 QQ，`wecom`、`wecom_ai_bot`、`weixin_official_account`、`weixin_oc` 至微信，`lark` 至飞书。未识别的平台默认拒绝；Satori 等通用适配器须由管理员明确设置 `platform` 并配置精确白名单。
6. 配置变更后重新加载插件，避免继续使用旧配置。

命令示例：`/mori 搜索 沙丘`、`/mori 订阅 三体`、`/mori 任务状态`、`/mori 下载 https://example.com/movie.mp4`。文本与最多五个资源标题、链接通过 `event.plain_result` 回复原渠道；每条最多 2500 字，总共最多四条。平台可能限制单条长度或链接发布，具体以平台权限为准。

搜索结果不会自动下载，插件不支持“下载第二个”或自动确认。用户应在 Mori 页面选择资源，或明确发送 HTTP(S) 下载直链，由 Mori 再次校验。不会绕过 Mori 的任务及意图限制，也不将模型输出当成签名密钥或平台凭据。

## 传输与故障

请求为 `/api/channels/bridge/{wechat|qq|feishu}`，仅发送 `eventId`、`peer`、`text`；事件 ID 由平台、UMO、平台原消息 ID 稳定派生。签名原文与 Mori 一致：UTF-8 `JSON.stringify([platform,timestamp,eventId,peer,text])`，HMAC-SHA256，时间戳秒数。没有稳定平台消息 ID 的请求不提交。

最多两条网络请求、八条处理中或等待的命令；满载明确拒绝，队列不落盘。HTTP 总期限约 18 秒，异步等待最多 20 秒，响应最多 256 KiB，无重试、无重定向；网络超时或 HTTP 409 时先在 Mori 核对，避免换消息重复提交写操作。禁用/卸载会取消等待，取消后不产生新回复；已发出的 HTTP 写操作不能撤销，需在 Mori 对账。底层已发出线程在自身超时内退出，两个线程槽位不会因取消而放大。

插件不记录 URL、密钥、用户消息或上游错误正文。远程部署请使用 HTTPS。`secret: true` 只遮罩 AstrBot 配置面板；宿主配置文件仍需管理员妥善保护。Mori 的进程内重放缓存重启会清空，因此不能保证跨重启 exactly-once；不要手动反复转发旧的写入指令。

## 验证范围与官方依据

依据 2026-10-23 官方文档：

- [最小插件示例](https://docs.astrbot.app/en/dev/star/guides/simple.html)：`Star`、`filter.command`、`event.plain_result`、`terminate`。
- [事件接口](https://docs.astrbot.app/en/dev/star/guides/listen-message-event.html)：事件内容、发送者和会话入口。
- [插件配置](https://docs.astrbot.app/en/dev/star/guides/plugin-config.html)：`AstrBotConfig`、`_conf_schema.json` 和敏感字段遮罩。

本仓库自测使用 Python 3.9 语法检查、模拟 AstrBot 导入与本地 HTTP 假服务，覆盖签名、序列化、默认拒绝、回复和取消。未实际安装 AstrBot，未验证真实微信、QQ、飞书账号；宿主和各平台互操作性仍需安装后验收。
