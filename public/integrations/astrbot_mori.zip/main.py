"""AstrBot command adapter for Mori's authenticated bridge; Python 3.9+."""
import asyncio
import hashlib
import hmac
import http.client
import json
import re
import threading
import time
from urllib.parse import urlsplit

from astrbot.api import AstrBotConfig
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.star import Context, Star


PLATFORMS = {
    "aiocqhttp": "qq", "qq_official": "qq", "qq_official_webhook": "qq",
    "wecom": "wechat", "wecom_ai_bot": "wechat",
    "weixin_official_account": "wechat", "weixin_oc": "wechat",
    "lark": "feishu",
}


def signed_message(platform, peer, message_id, text, secret, timestamp=None):
    if platform not in {"qq", "wechat", "feishu"} or not secret:
        raise ValueError("Bridge configuration is incomplete")
    if not isinstance(peer, str) or not peer.strip() or len(peer) > 200 or re.search(r"[\x00-\x1f\x7f]", peer):
        raise ValueError("Invalid session")
    if not message_id or not isinstance(text, str) or not text.strip() or len(text) > 4000:
        raise ValueError("Invalid message")
    event_id = hashlib.sha256(json.dumps([platform, peer, str(message_id)], ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
    timestamp = str(int(time.time()) if timestamp is None else timestamp)
    body = {"eventId": event_id, "peer": peer, "text": text}
    canonical = json.dumps([platform, timestamp, event_id, peer, text], ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    headers = {"Content-Type": "application/json", "X-Mori-Timestamp": timestamp, "X-Mori-Signature": hmac.new(secret.encode("utf-8"), canonical, hashlib.sha256).hexdigest()}
    return json.dumps(body, ensure_ascii=False, separators=(",", ":")).encode("utf-8"), headers


def bridge_post(base_url, platform, payload, headers):
    target = urlsplit(base_url)
    if target.scheme not in ("http", "https") or not target.hostname or target.username or target.password or target.query or target.fragment:
        raise ValueError("Invalid Mori URL")
    connection_type = http.client.HTTPSConnection if target.scheme == "https" else http.client.HTTPConnection
    connection = connection_type(target.hostname, target.port, timeout=10)
    deadline = time.monotonic() + 18
    try:
        path = target.path.rstrip("/") + "/api/channels/bridge/" + platform
        connection.request("POST", path, payload, headers)
        sock = connection.sock
        if sock:
            sock.settimeout(max(0.1, deadline - time.monotonic()))
        response = connection.getresponse()
        if response.status != 200:
            # Never expose the server's error body or retry a possibly executed command.
            raise ValueError("Bridge HTTP %d" % response.status)
        chunks, size = [], 0
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("Bridge deadline exceeded")
            if sock:
                sock.settimeout(remaining)
            chunk = response.read1(8192)
            if not chunk:
                break
            size += len(chunk)
            if size > 256 * 1024:
                raise ValueError("Bridge response too large")
            chunks.append(chunk)
        reply = json.loads(b"".join(chunks))
        if not isinstance(reply, dict) or not isinstance(reply.get("text"), str):
            raise ValueError("Invalid bridge response")
        return reply
    finally:
        connection.close()


def reply_text(reply):
    text = reply["text"][:4000]
    results = reply.get("results")
    if isinstance(results, list) and results:
        lines = []
        for item in results[:5]:
            if not isinstance(item, dict):
                continue
            title = str(item.get("title", "资源"))[:150]
            url = str(item.get("url", ""))[:1200]
            lines.append("%s\n%s" % (title, url))
        text += "\n\n" + "\n\n".join(lines) + "\n\n请在 Mori 界面选择资源；下载需明确发送 /mori 下载 HTTP(S)直链。"
    return text[:10000]


class MoriPlugin(Star):
    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.config = config
        self._limit = asyncio.Semaphore(2)
        self._threads = threading.BoundedSemaphore(2)
        self._pending = 0
        self._running = set()
        self._closed = False

    def _request(self, platform, peer, message_id, text):
        if not self._threads.acquire(blocking=False):
            raise ValueError("Bridge workers busy")
        try:
            if self._closed:
                raise ValueError("Plugin stopped")
            payload, headers = signed_message(platform, peer, message_id, text, str(self.config.get("bridge_secret", "")))
            return bridge_post(str(self.config.get("mori_url", "")), platform, payload, headers)
        finally:
            self._threads.release()

    @filter.command("mori")
    async def mori(self, event: AstrMessageEvent):
        """/mori 搜索片名、订阅剧集、查询任务或提交明确的下载直链。"""
        platform = self.config.get("platform", "auto")
        if platform == "auto":
            platform = PLATFORMS.get(event.get_platform_name())
        sender = str(event.get_sender_id())
        peer = event.unified_msg_origin
        users, sessions = self.config.get("allowed_users", []), self.config.get("allowed_sessions", [])
        if self._closed or platform not in {"qq", "wechat", "feishu"} or not isinstance(users, list) or not isinstance(sessions, list) or "%s:%s" % (platform, sender) not in users or peer not in sessions:
            return
        event.stop_event()
        match = re.match(r"^/?mori(?:\s+|$)(.*)$", event.message_str.strip(), re.DOTALL)
        text = match.group(1).strip() if match else ""
        if not text or len(text) > 4000:
            yield event.plain_result("用法：/mori 搜索 沙丘；/mori 订阅 三体；/mori 任务状态；/mori 下载 HTTP(S)直链。消息最多 4000 字。")
            return
        if self._pending >= 8:
            yield event.plain_result("Mori 正忙，请稍后再试。尚未提交本次操作。")
            return
        task = asyncio.current_task()
        self._running.add(task)
        self._pending += 1
        try:
            async with self._limit:
                if self._closed:
                    return
                try:
                    message_id = getattr(event.message_obj, "message_id", None)
                    reply = await asyncio.wait_for(asyncio.to_thread(self._request, platform, peer, message_id, text), timeout=20)
                except asyncio.CancelledError:
                    raise
                except Exception:
                    if not self._closed:
                        yield event.plain_result("Mori 请求未确认，请检查连接、签名密钥和授权。请先在 Mori 核对任务，勿重复提交下载或订阅。")
                    return
                if not self._closed:
                    formatted = reply_text(reply)
                    for start in range(0, len(formatted), 2500):
                        if self._closed:
                            return
                        yield event.plain_result(formatted[start:start + 2500])
        finally:
            self._pending -= 1
            self._running.discard(task)

    async def terminate(self):
        self._closed = True
        tasks = [task for task in self._running if task is not asyncio.current_task()]
        for task in tasks:
            task.cancel()
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
